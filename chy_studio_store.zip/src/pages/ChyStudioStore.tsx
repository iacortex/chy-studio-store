import React, { useEffect, useState } from "react";
import AnimatedBackground from "../components/ui/AnimatedBackground";
import Header from "../components/layout/Header";
import Footer from "../components/layout/Footer";
import Hero from "../sections/Hero";
import Products from "../sections/Products";
import Services from "../sections/Services";
import Contact from "../sections/Contact";
import CartSidebar from "../sections/CartSidebar";
import { CartItem, CategoryId, Product } from "../types/store";

export default function ChyStudioStore() {
  const [cart,setCart]=useState<CartItem[]>([]);
  const [favorites,setFavorites]=useState<number[]>([]);
  const [isMenuOpen,setIsMenuOpen]=useState(false);
  const [selectedCategory,setSelectedCategory]=useState<CategoryId>("todos");
  const [searchTerm,setSearchTerm]=useState("");
  const [isCartOpen,setIsCartOpen]=useState(false);
  const [mousePosition,setMousePosition]=useState({x:0,y:0});

  useEffect(()=>{ const h=(e:MouseEvent)=>setMousePosition({x:e.clientX,y:e.clientY});
    window.addEventListener("mousemove",h); return()=>window.removeEventListener("mousemove",h); },[]);

  const addToCart=(p:Product)=>{ const ex=cart.find(i=>i.id===p.id);
    setCart(ex? cart.map(i=>i.id===p.id?{...i,quantity:i.quantity+1}:i): [...cart,{...p,quantity:1}]); };
  const removeFromCart=(id:number)=>setCart(cart.filter(i=>i.id!==id));
  const updateQuantity=(id:number,q:number)=> q<=0?removeFromCart(id):setCart(cart.map(i=>i.id===id?{...i,quantity:q}:i));
  const toggleFavorite=(id:number)=> setFavorites(f=>f.includes(id)?f.filter(x=>x!==id):[...f,id]);
  const getTotal=()=> cart.reduce((t,i)=>t+i.price*i.quantity,0);

  const onWhatsApp=()=> {
    const body=cart.map(i=>`${i.name} - Cantidad: ${i.quantity} - $${(i.price*i.quantity).toLocaleString()}`).join("\n");
    const msg=`¡Hola CHY STUDIO! 🎨\n\nMe interesa este pedido:\n\n${body}\n\nTotal: $${getTotal().toLocaleString()}\n\n¡Gracias!`;
    window.open(`https://wa.me/56941841436?text=${encodeURIComponent(msg)}`,"_blank");
  };

  return (
    <div className="min-h-screen bg-black text-white relative overflow-x-hidden">
      <AnimatedBackground x={mousePosition.x} y={mousePosition.y}/>
      <Header cartCount={cart.reduce((s,i)=>s+i.quantity,0)} onOpenCart={()=>setIsCartOpen(true)} isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen}/>
      <Hero/>
      <Products selectedCategory={selectedCategory} setSelectedCategory={setSelectedCategory}
        searchTerm={searchTerm} setSearchTerm={setSearchTerm}
        favorites={favorites} toggleFavorite={toggleFavorite} addToCart={addToCart}/>
      <Services/>
      <Contact/>
      <Footer/>
      <CartSidebar open={isCartOpen} onClose={()=>setIsCartOpen(false)} cart={cart}
        updateQuantity={updateQuantity} removeFromCart={removeFromCart}
        getTotal={getTotal} onWhatsApp={onWhatsApp}/>
    </div>
  );
}
