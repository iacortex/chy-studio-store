// src/sections/Products.tsx
import { useMemo } from 'react';
import { ShoppingCart, Heart, Star, Search, Filter, Sparkles, Zap } from 'lucide-react';

// 👇 Importaciones SOLO DE TIPO (para verbatimModuleSyntax)
import type { CategoryId, Product } from '../types';

// 👇 Componentes reutilizables
import MagneticButton from '../components/MagneticButton';
import FloatingCard from '../components/FloatingCard';

type UiCategory = {
  id: CategoryId | 'todos';
  name: string;
  icon: 'sparkles' | 'zap' | string; // puede ser nombre especial o emoji/texto
  color: string; // tailwind gradient tokens: "from-... to-..."
};

type ProductsProps = {
  products: Product[];
  categories: UiCategory[];
  selectedCategory: CategoryId | 'todos';
  setSelectedCategory: (id: CategoryId | 'todos') => void;

  searchTerm: string;
  setSearchTerm: (value: string) => void;

  favorites: Array<Product['id']>;
  toggleFavorite: (id: Product['id']) => void;

  addToCart: (product: Product) => void;
};

export default function Products({
  products,
  categories,
  selectedCategory,
  setSelectedCategory,
  searchTerm,
  setSearchTerm,
  favorites,
  toggleFavorite,
  addToCart,
}: ProductsProps) {
  const filteredProducts = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return products.filter((p) => {
      const matchesCategory =
        selectedCategory === 'todos' || p.category === selectedCategory;
      const matchesSearch =
        term.length === 0 ||
        p.name.toLowerCase().includes(term) ||
        (p.description?.toLowerCase().includes(term) ?? false);
      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchTerm]);

  return (
    <section id="productos" className="py-32 px-4 relative">
      <div className="max-w-7xl mx-auto">
        {/* Título */}
        <div className="text-center mb-16">
          <h2 className="text-5xl font-black mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            Productos Extraordinarios
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Cada producto es una obra maestra diseñada para superar expectativas
          </p>
        </div>

        {/* Buscador */}
        <div className="mb-12 flex flex-col md:flex-row gap-6 items-center justify-between">
          <div className="relative flex-1 max-w-2xl group">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur-lg opacity-0 group-focus-within:opacity-100 transition-all duration-500" />
            <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl group-focus-within:border-purple-500/50 transition-all duration-300">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400 group-focus-within:text-purple-400 transition-colors duration-300" />
              <input
                type="text"
                placeholder="Buscar productos increíbles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-14 pr-8 py-5 bg-transparent text-white placeholder-gray-400 focus:outline-none text-lg"
              />
              {searchTerm && (
                <div className="absolute right-6 top-1/2 -translate-y-1/2">
                  <span className="bg-purple-600/20 text-purple-300 text-sm px-3 py-1 rounded-full border border-purple-500/30">
                    {filteredProducts.length} encontrados
                  </span>
                </div>
              )}
            </div>
          </div>

          <MagneticButton variant="secondary" className="px-6 py-5 rounded-2xl border border-white/20">
            <span className="flex items-center space-x-2">
              <Filter className="w-5 h-5" />
              <span>Filtros</span>
            </span>
          </MagneticButton>
        </div>

        {/* Categorías */}
        <div className="mb-16 overflow-x-auto pb-4">
          <div className="flex space-x-4 min-w-max">
            {categories.map((category) => (
              <MagneticButton
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-4 rounded-2xl font-bold whitespace-nowrap transition-all duration-300 ${
                  selectedCategory === category.id
                    ? `bg-gradient-to-r ${category.color} shadow-lg`
                    : 'bg-white/5 border border-white/20 hover:bg-white/10'
                }`}
              >
                <span className="flex items-center space-x-3">
                  {category.icon === 'sparkles' ? (
                    <Sparkles className="w-5 h-5" />
                  ) : category.icon === 'zap' ? (
                    <Zap className="w-5 h-5" />
                  ) : (
                    <span className="text-xl">{category.icon}</span>
                  )}
                  <span>{category.name}</span>
                </span>
              </MagneticButton>
            ))}
          </div>
        </div>

        {/* Grid de productos */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <FloatingCard key={product.id}>
              <div className="group relative bg-gradient-to-br from-white/5 to-white/0 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/10 hover:border-white/20 transition-all duration-500 hover:shadow-2xl">
                {/* Glow */}
                <div
                  className={`absolute inset-0 bg-gradient-to-r ${product.gradient ?? 'from-purple-500 to-pink-500'} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
                />
                {/* Imagen */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  {/* Favorito */}
                  <button
                    onClick={() => toggleFavorite(product.id)}
                    className="absolute top-4 right-4 w-12 h-12 bg-black/40 backdrop-blur-sm rounded-2xl flex items-center justify-center transition-all duration-300 hover:bg-black/60 hover:scale-110 border border-white/20"
                  >
                    <Heart
                      className={`w-6 h-6 transition-colors duration-300 ${
                        favorites.includes(product.id)
                          ? 'fill-red-500 text-red-500'
                          : 'text-white hover:text-red-400'
                      }`}
                    />
                  </button>

                  {/* Badge */}
                  {product.badge && (
                    <div
                      className={`absolute top-4 left-4 bg-gradient-to-r ${
                        product.gradient ?? 'from-purple-500 to-pink-500'
                      } text-white text-sm font-bold px-4 py-2 rounded-full shadow-lg`}
                    >
                      {product.badge}
                    </div>
                  )}

                  {/* Oferta */}
                  {product.originalPrice && (
                    <div className="absolute bottom-4 right-4 bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full animate-pulse">
                      -
                      {Math.round(
                        ((product.originalPrice - product.price) / product.originalPrice) * 100
                      )}
                      %
                    </div>
                  )}
                </div>

                {/* Contenido */}
                <div className="p-6">
                  {/* Categoría */}
                  <div className="inline-block mb-3">
                    <span className="px-3 py-1 text-xs font-semibold bg-purple-500/20 text-purple-300 rounded-full border border-purple-500/30">
                      {categories.find((c) => c.id === product.category)?.name ?? product.category}
                    </span>
                  </div>

                  {/* Título */}
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-purple-300 transition-colors duration-300">
                    {product.name}
                  </h3>

                  {/* Descripción */}
                  {product.description && (
                    <p className="text-gray-400 text-sm leading-relaxed mb-4">{product.description}</p>
                  )}

                  {/* Rating */}
                  <div className="flex items-center mb-6 space-x-2">
                    <div className="flex items-center space-x-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 transition-colors duration-200 ${
                            i < Math.floor(product.rating ?? 0)
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-slate-600'
                          }`}
                        />
                      ))}
                    </div>
                    {typeof product.rating === 'number' && (
                      <span className="text-yellow-400 text-sm font-medium">{product.rating}</span>
                    )}
                    {typeof product.reviews === 'number' && (
                      <span className="text-gray-500 text-xs">({product.reviews} reviews)</span>
                    )}
                  </div>

                  {/* Precio */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                        ${product.price.toLocaleString()}
                      </span>
                      {product.originalPrice && (
                        <span className="text-lg text-gray-500 line-through">
                          ${product.originalPrice.toLocaleString()}
                        </span>
                      )}
                    </div>

                    {product.originalPrice && (
                      <div className="bg-red-500/20 text-red-400 text-xs font-bold px-2 py-1 rounded">
                        -
                        {Math.round(
                          ((product.originalPrice - product.price) / product.originalPrice) * 100
                        )}
                        %
                      </div>
                    )}
                  </div>

                  {/* Acción */}
                  <MagneticButton
                    onClick={() => addToCart(product)}
                    className="w-full py-3 px-6 rounded-2xl text-white font-semibold"
                  >
                    <span className="flex items-center justify-center space-x-2">
                      <ShoppingCart className="w-5 h-5" />
                      <span>Agregar al Carrito</span>
                    </span>
                  </MagneticButton>

                  {/* Línea decorativa */}
                  <div
                    className={`absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r ${
                      product.gradient ?? 'from-purple-500 to-pink-500'
                    } transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left`}
                  />
                </div>
              </div>
            </FloatingCard>
          ))}
        </div>
      </div>
    </section>
  );
}
