import React, { useState } from "react";
export default function FloatingCard({children,className=""}:{children:React.ReactNode;className?:string;}) {
  const [t,setT]=useState({x:0,y:0,rx:0,ry:0});
  const move=(e:React.MouseEvent<HTMLDivElement>)=>{
    const r=e.currentTarget.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
    setT({ ry:((e.clientX-cx)/r.width)*10, rx:((cy-e.clientY)/r.height)*10, x:((e.clientX-cx)/r.width)*5, y:((e.clientY-cy)/r.height)*5 });
  };
  return (
    <div onMouseMove={move} onMouseLeave={()=>setT({x:0,y:0,rx:0,ry:0})}
         className={`transition-all duration-300 ${className}`}
         style={{transform:`perspective(1000px) rotateX(${t.rx}deg) rotateY(${t.ry}deg) translate3d(${t.x}px, ${t.y}px, 0)`}}>
      {children}
    </div>
  );
}
