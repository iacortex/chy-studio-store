import React, { useState } from "react";
export default function MagneticButton({
  children,onClick,className="",variant="primary",
}:{children:React.ReactNode;onClick?:()=>void;className?:string;variant?:"primary"|"secondary"|"success";}) {
  const [pos,setPos]=useState({x:0,y:0}); const [hover,setHover]=useState(false);
  const handleMove=(e:React.MouseEvent<HTMLButtonElement>)=>{
    const r=e.currentTarget.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
    setPos({x:(e.clientX-cx)*0.1,y:(e.clientY-cy)*0.1});
  };
  const variants={primary:"bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500",
                  secondary:"bg-gradient-to-r from-slate-800 to-slate-700 hover:from-slate-700 hover:to-slate-600",
                  success:"bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500"};
  return (
    <button onClick={onClick} onMouseMove={handleMove} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>{setPos({x:0,y:0});setHover(false);}}
      className={`relative overflow-hidden font-semibold text-white transition-all duration-300 transform hover:scale-105 active:scale-95 shadow-lg hover:shadow-xl ${variants[variant]} ${className}`}
      style={{transform:`translate(${pos.x}px, ${pos.y}px) scale(${hover?1.05:1})`}}>
      <div className="relative z-10">{children}</div>
      {hover && <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-white/10 animate-pulse" />}
    </button>
  );
}
