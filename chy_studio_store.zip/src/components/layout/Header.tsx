
import { Menu, X, ShoppingCart } from "lucide-react";
import MagneticButton from "../ui/MagneticButton";
export default function Header({
  cartCount,onOpenCart,isMenuOpen,setIsMenuOpen,
}:{cartCount:number;onOpenCart:()=>void;isMenuOpen:boolean;setIsMenuOpen:(v:boolean)=>void;}) {
  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-black/80 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-4">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl blur-lg opacity-75 group-hover:opacity-100 transition-opacity animate-pulse" />
              <div className="relative w-14 h-14 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center">
                <span className="text-white font-black text-xl">CHY</span>
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-black bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">CHY STUDIO</h1>
              <p className="text-sm text-gray-400 font-medium">Diseño del Futuro</p>
            </div>
          </div>
          <nav className="hidden md:flex space-x-8">
            {["Inicio","Productos","Servicios","Contacto"].map(i=>(
              <a key={i} href={`#${i.toLowerCase()}`} className="relative group px-4 py-2 text-gray-300 hover:text-white transition-all duration-300">
                <span className="relative z-10">{i}</span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600/0 via-pink-600/50 to-purple-600/0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-sm" />
              </a>
            ))}
          </nav>
          <div className="flex items-center space-x-4">
            <MagneticButton onClick={onOpenCart} className="p-4 rounded-2xl relative">
              <ShoppingCart className="w-6 h-6"/>
              {cartCount>0 && <span className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full text-xs flex items-center justify-center font-bold animate-bounce">{cartCount}</span>}
            </MagneticButton>
            <button onClick={()=>setIsMenuOpen(!isMenuOpen)} className="md:hidden p-4 rounded-2xl bg-gradient-to-r from-slate-800 to-slate-700">
              {isMenuOpen ? <X className="w-6 h-6"/> : <Menu className="w-6 h-6"/>}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
