import React from "react";
import ChyStudioStore from "./pages/ChyStudioStore";
export default function App(){ return <ChyStudioStore/>; }
