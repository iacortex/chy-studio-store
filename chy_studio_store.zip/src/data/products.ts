import { Product } from "../types/store";
export const products: Product[] = [
  { id:1, name:"Taza Mágica Personalizada", category:"sublimacion", price:15000, originalPrice:20000,
    image:"https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=500&h=500&fit=crop&auto=format",
    rating:4.8, reviews:124, description:"Taza que cambia de color con líquidos calientes. Personalízala.",
    badge:"Más Vendido", gradient:"from-purple-500 to-pink-500" },
  { id:2, name:"Kit Cumpleaños Premium", category:"cumpleanos", price:45000, originalPrice:55000,
    image:"https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=500&h=500&fit=crop&auto=format",
    rating:4.9, reviews:87, description:"Kit completo y personalizable.", badge:"Premium",
    gradient:"from-pink-500 to-rose-500" },
  // … agrega el resto igual que tu referencia …
];
